class LibrosController < ApplicationController

  def  index
    @libros=Libro.all
  end

  def show
    @libros=Libro.find(params[:id])
  end

  def new
    @libros=Libro.new
  end

  def edit
    @libros=Libro.find(params[:id])
  end

  def create
    #@articles=Article.new(title: params[:article][:title],body: params[:article][:body]) #este era para crear nuevos
  @libros=Libro.new(libro_params)# este crea y edita
    if @libros.save
    redirect_to@libros
  else
    render:new
  end#end if
end#end create


  def update
    @libros=Libro.find(params[:id])
    if @libros.update(libro_params)
      redirect_to@libros
    else
      render :edit
  end
end


  private
  def libro_params
      params.require(:libro).permit(:titulo, :autor, :editorial, :numero_paginas)
  end

end
