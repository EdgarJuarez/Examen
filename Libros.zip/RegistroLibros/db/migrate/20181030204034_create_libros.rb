class CreateLibros < ActiveRecord::Migration
  def change
    create_table :libros do |t|
      t.string :titulo
      t.string :subtitulo
      t.string :autor
      t.string :editorial
      t.string :year_publicacion
      t.string :numero_paginas

      t.timestamps null: false
    end
  end
end
