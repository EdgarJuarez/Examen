class AddUserIdToLibros < ActiveRecord::Migration
  def change
    add_reference :libros, :user, foreign_key: true

  end
end
